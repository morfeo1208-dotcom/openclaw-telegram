# Seguridad del servidor

- Usa HTTPS; no configures tráfico HTTP sin cifrar en la app de producción.
- Define `VISHNU_MOBILE_TOKEN` en el entorno del servicio Flask con un secreto largo y aleatorio.
- El token de ejemplo sirve para validar la integración, pero un secreto compartido dentro de una APK se puede extraer. No lo uses para una app pública.
- No expongas el endpoint sin autenticación, límite de peticiones y control de longitud.
- El código web actual concatena mensajes y respuestas en `innerHTML`. Eso permite inyección HTML/JS. Cambia el cliente web a `textContent` o crea nodos DOM; no insertes texto del usuario con `innerHTML`.
- El endpoint existente `/api/chat` utiliza un único `user_id=999999` para todos los visitantes. No lo reutilices para varios usuarios: sus conversaciones podrían mezclarse. El parche usa un ID de dispositivo configurable para una instalación personal; para varios usuarios, autentica a cada usuario y usa un ID distinto por cuenta.
- Mantén `GEMINI_API_KEY` exclusivamente en el servidor.
