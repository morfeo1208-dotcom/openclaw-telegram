# INSTRUCCIONES: NO reemplaces app.py. Añade `import hmac` junto a los imports.
# Añade este endpoint al final de app.py, después de definir procesar_con_ia.
# En Render configura VISHNU_MOBILE_TOKEN y VISHNU_MOBILE_USER_ID.

@app.route("/api/mobile/chat", methods=["POST"])
def api_mobile_chat():
    expected = os.environ.get("VISHNU_MOBILE_TOKEN", "")
    configured_user_id = os.environ.get("VISHNU_MOBILE_USER_ID", "")

    if not expected or not configured_user_id:
        return jsonify({"error": "API móvil no configurada"}), 503

    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return jsonify({"error": "No autorizado"}), 401
    if not hmac.compare_digest(auth[7:].strip(), expected):
        return jsonify({"error": "No autorizado"}), 401

    if not request.is_json:
        return jsonify({"error": "Se requiere JSON"}), 415

    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    if not isinstance(message, str):
        return jsonify({"error": "Mensaje inválido"}), 400
    message = message.strip()
    if not message:
        return jsonify({"error": "Escribe un mensaje"}), 400
    if len(message) > 2000:
        return jsonify({"error": "Mensaje demasiado largo"}), 413

    try:
        user_id = int(configured_user_id)
        # Reutiliza lógica de Gemini y recordatorios existente.
        reply = procesar_con_ia(
            user_id,
            message,
            tipo="texto",
            nombre_usuario=os.environ.get("VISHNU_MOBILE_NAME", "Andy")
        )
        return jsonify({"reply": reply})
    except Exception:
        logger.exception("Error en /api/mobile/chat")
        return jsonify({"error": "Vishnú no pudo procesar el mensaje"}), 500
