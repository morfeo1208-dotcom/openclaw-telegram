# Vishnú Flotante — compilación en el Samsung A24

Este paquete contiene una plantilla Android nativa. No modifica `app.py` ni otras funciones de Flask/Telegram. La app Android llama a `https://TU-SERVICIO.onrender.com/api/mobile/chat`.

## 1. Instalar Termux

Instala Termux desde F-Droid o el GitHub oficial de Termux (no una versión antigua de Play Store). Abre Termux y ejecuta:

```bash
pkg update && pkg upgrade -y
pkg install -y git python openjdk-17 gradle aapt aapt2 apksigner unzip
termux-setup-storage
```

Si algún paquete no existe en tu repositorio Termux, actualiza Termux desde la misma fuente e inténtalo de nuevo. No instales APKs de fuentes desconocidas.

## 2. Preparar herramientas Android ARM64

El empaquetado Android en un móvil puede fallar si Gradle intenta ejecutar el `aapt2` x86 de Google. Usa la guía de `termux-android-build` para instalar/configurar el SDK y el override ARM64:

```bash
cd ~
git clone https://github.com/Xtratter/termux-android-build
bash termux-android-build/setup.sh
```

Lee el README del proyecto antes de ejecutar el script y revisa los cambios que propone. Requiere espacio libre; la primera preparación descarga SDK y herramientas.

## 3. Copiar el proyecto

Descomprime este paquete y coloca la carpeta `android-avatar` dentro del repositorio `openclaw-telegram`:

```text
openclaw-telegram/
  app.py                 # existente, conservar
  ...                    # archivos actuales, conservar
  android-avatar/        # proyecto nuevo
```

Puedes descargar el ZIP al teléfono, dar acceso a Termux y descomprimirlo en `$HOME` o en el repositorio clonado. No sobrescribas `app.py`.

## 4. Crear wrapper y compilar

Desde el directorio `android-avatar`:

```bash
cd ~/openclaw-telegram/android-avatar
# Asegúrate de usar Gradle 8.9 o 8.10.x con AGP 8.7.3.
gradle wrapper --gradle-version 8.10.2
bash ./gradlew assembleDebug --no-daemon
```

Si falla por `aapt2`, consulta la sección de ARM64/aapt2 del README de termux-android-build y aplica el override indicado allí. No cambies el archivo Gradle del proyecto para rutas específicas del teléfono; el ajuste puede quedar en `~/.gradle/gradle.properties`.

APK esperado:
`app/build/outputs/apk/debug/app-debug.apk`

Copiar a Descargas:
```bash
mkdir -p ~/storage/downloads
cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/VishnuFlotante-debug.apk
```

Instala el APK desde Descargas. Android puede pedir autorización para instalar apps desconocidas.

## 5. Conectar con Render

Abre Vishnú Flotante, introduce la URL base HTTPS de tu servicio Render y el token móvil que configuraste en Render. La URL debe ser la base, sin `/api/mobile/chat`; la app agrega esa ruta.

## Límites importantes

- Esta plantilla debe compilarse y probarse en tu dispositivo; la compilación local ARM64 puede requerir ajustes del SDK/aapt2 y consumir varios GB.
- El APK debug no es una versión de publicación.
- Un token compartido guardado en el teléfono puede extraerse; úsalo solo para pruebas personales y revócalo si se filtra.
- No introduzcas `GEMINI_API_KEY` en Android.
