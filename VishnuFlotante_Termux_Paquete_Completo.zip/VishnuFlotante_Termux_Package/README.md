# Vishnú Flotante — plantilla Android para integrar con Flask existente

La carpeta `android-avatar/` es una app Android nativa Kotlin separada del servidor Python. No reemplaza ni modifica funciones de Telegram, SQLite, Gemini ni Flask.

## Servidor

Aplica manualmente el endpoint descrito en `server_patch.py` en el archivo `app.py` existente, añade `import hmac` junto a los imports y configura `VISHNU_MOBILE_TOKEN` y `VISHNU_MOBILE_USER_ID` en Render. Revisa `SEGURIDAD.md` antes de exponerlo.

## Compilación

Consulta `termux/README-ES.md` para compilar en el Samsung A24 usando Termux. La plantilla no contiene Gradle Wrapper binario ni un APK ya compilado.
